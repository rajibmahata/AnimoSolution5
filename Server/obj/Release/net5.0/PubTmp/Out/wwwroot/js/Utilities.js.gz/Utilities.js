﻿function getBack(value) {
        window.history.go(value);
}

